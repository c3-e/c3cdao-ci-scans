# `@c3-e/eslint-plugin`

An [ESLint][] plugin for C3 AI.

Version history is documented in the [changelog](CHANGELOG.md) file.

## Installation

You must first install [ESLint][]:

```shell
$ npm i -D eslint
```

Next, install `@c3-e/eslint-plugin`:

```shell
$ npm i -D @c3-e/eslint-plugin
```

**Note:** If you installed ESLint globally (using the `-g` flag) then you must also install `@c3-e/eslint-plugin`
globally. The `@c3-e/eslint-plugin` can be downloaded from the [C3 npm registry](https://ci-artifacts.c3.ai/npms). At
time of writing, the C3 internal registry doesn't yet support scoped npm modules, and the package must be installed with
the direct URL.

## Usage

Add `c3-e` to the plugins section of your `.eslintrc` configuration file. You can omit the `/eslint-plugin` suffix:

```json
{
  "plugins": ["@c3-e"]
}
```

Then configure the rules you want to use under the rules section.

```json
{
  "rules": {
    "@c3-e/rule-name": 2
  }
}
```

You can also extend one or more of the available configuration presets, which includes rule configurations, environment
configurations, and global variable declarations.

```json
{
  "extends": ["plugin:@c3-e/jsx-template", "plugin:@c3-e/react", "plugin:@c3-e/style-guide"]
}
```

## Supported Config Presets

- `@c3-e/style-guide`: Configuration of rules that align with the C3 JavaScript Style Guide. Generally, it's best to use
  pure formatters for styling code, so we encourage using `@c3-e/style-guide-prettier` in combination with [Prettier][].
  If your project doesn't integrate with [Prettier][], this preset can be used. It enforces styling that's _very
  similar_ to [Prettier][] version 3 configured with:

  ```json
  {
    "arrowParens": "always",
    "bracketSpacing": true,
    "semi": true,
    "singleQuote": true,
    "tabWidth": 2,
    "trailingComma": "es5",
    "useTabs": false
  }
  ```

  While _no conflicts_ are guaranteed, the styling isn't guaranteed to _exactly_ match. This means the output of
  `prettier --write` and `eslint --fix` won't always exactly match, but `eslint` will never throw errors for code
  formatted with `prettier --write` using the above configurations.

  - Optional dependency [`eslint-plugin-import`][] is required when this preset is used.

- `@c3-e/style-guide-prettier`: Same as `@c3-e/style-guide` but with all styling rules that conflict with [Prettier][]
  turned off. Instead, all formatting will be handled by the `prettier/prettier` rule. The `prettier/prettier` rule
  should be configured through a [`.prettierrc` file](https://prettier.io/docs/en/options) and [ESLint][] will respect
  any configurations with the following exceptions:

  - The [`quotes` rule](https://eslint.org/docs/latest/rules/quotes) remains enabled and is configured with
    `['error', 'single', { avoidEscape: true, allowTemplateLiterals: false }]`. This is slightly more powerful than
    [Prettier's `singleQuote` option](https://prettier.io/docs/en/options#quotes) because it auto-fixes unnecessary
    template literals. For example:

    ```javascript
    const fileName = `cover-image.png`;
    // Becomes
    const fileName = 'cover-image.png';
    ```

    Even when using this preset, [Prettier][] **must be configured with** `{ singleQuote: true }`

  The following optional dependencies are required when this preset is used:

  - [`eslint-plugin-import`][]
  - [`eslint-plugin-prettier`][]
  - [`eslint-config-prettier`][]

- `@c3-e/jasmine`: Recommended configurations of rules from [`eslint-plugin-jasmine`][].
  - Optional dependency [`eslint-plugin-jasmine`][] is required when this preset is used.
- `@c3-e/react`: Recommended configurations of rules from [`eslint-plugin-react`][].
  - Optional dependency [`eslint-plugin-react`][] is required when this preset is used.
- `@c3-e/jsx-template`: Recommended configurations of rules from [`eslint-plugin-react`][], specific for JSX template
  files.
  - Optional dependency [`eslint-plugin-react`][] is required when this preset is used.
- `@c3-e/c3-base`: Configuration of rules that align with the C3 JavaScript Style Guide and web security.
  - Optional dependency [`eslint-plugin-import`][] is required when this preset is used.
- `@c3-e/esnext`: Configuration of rules for ES6 files.
- `@c3-e/typescript`: Recommended configurations of rules from [`@typescript-eslint`][] and custom C3 TypeScript rules.
  - The following optional dependencies are required when this preset is used:
    - [`eslint-plugin-react`][],
    - [`@typescript-eslint/eslint-plugin`][],
    - [`@typescript-eslint/parser`][]
    - [`typescript`][]

## Supported Rules

- [`@c3-e/directive-invalid-metric-code`](docs/rules/directive-invalid-metric-code.md): Disallow invalid code analysis
  metric code in directive comments.
- [`@c3-e/directive-no-reason-provided`](docs/rules/directive-no-reason-provided.md): Disallow missing reason for
  disabling code analysis metric in directive comments.
- [`@c3-e/enzyme-no-find-by-display-name`](docs/rules/enzyme-no-find-by-display-name.md): Disallow using Enzyme's `find`
  with a component display name.
- [`@c3-e/jasmine-enzyme-prefer-toContainExactlyOneMatchingElement`](docs/rules/jasmine-enzyme-prefer-toContainExactlyOneMatchingElement.md):
  Prefer jasmine-enzyme matcher toContainExactlyOneMatchingElement.
- [`@c3-e/jasmine-enzyme-prefer-toContainMatchingElement`](docs/rules/jasmine-enzyme-prefer-toContainMatchingElement.md):
  Prefer jasmine-enzyme matcher toContainMatchingElement.
- [`@c3-e/jasmine-enzyme-prefer-toContainMatchingElements`](docs/rules/jasmine-enzyme-prefer-toContainMatchingElements.md):
  Prefer jasmine-enzyme matcher toContainMatchingElements.
- [`@c3-e/jsx-no-inline-style`](docs/rules/jsx-no-inline-style.md): Disallow inline style in JSX.
- [`@c3-e/jsx-no-type-prop`](docs/rules/jsx-no-type-prop.md): Disallow `type` prop.
- [`@c3-e/security-no-createContextualFragment`](docs/rules/security-no-createContextualFragment.md): Disallow
  `createContextualFragment` for XSS security vulnerability.
- [`@c3-e/security-no-window-open`](docs/rules/security-no-window-open.md): Disallow `window.open()` for XSS security
  vulnerability.
- [`@c3-e/security-no-jquery-after`](docs/rules/security-no-jquery-after.md): Disallow jQuery `after` XSS security
  vulnerability.
- [`@c3-e/security-no-jquery-append`](docs/rules/security-no-jquery-append.md): Disallow jQuery `append` XSS security
  vulnerability.
- [`@c3-e/security-no-jquery-html`](docs/rules/security-no-jquery-html.md): Disallow jQuery `html` XSS security
  vulnerability.

[eslint]: http://eslint.org
[prettier]: https://prettier.io/
[`eslint-config-prettier`]: https://github.com/prettier/eslint-config-prettier
[`eslint-plugin-prettier`]: https://github.com/prettier/eslint-plugin-prettier
[`eslint-plugin-jasmine`]: https://github.com/tlvince/eslint-plugin-jasmine
[`eslint-plugin-react`]: https://github.com/yannickcr/eslint-plugin-react
[`eslint-plugin-import`]: https://github.com/import-js/eslint-plugin-import
[`@typescript-eslint`]: https://github.com/typescript-eslint/typescript-eslint
[`@typescript-eslint/eslint-plugin`]: https://github.com/typescript-eslint/typescript-eslint
[`@typescript-eslint/parser`]: https://github.com/typescript-eslint/typescript-eslint
[`typescript`]: https://github.com/Microsoft/TypeScript
